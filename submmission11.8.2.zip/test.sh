#!/bin/bash

# compile.sh - 编译 C++ 程序脚本

echo "=========================================="
echo "        C++ 程序编译脚本"
echo "=========================================="

# 1. 显示当前路径
echo "📁 当前工作目录: $(pwd)"
echo "📋 当前目录文件列表:"
ls -la

echo "------------------------------------------"

# 2. 检查 test.cpp 文件是否存在
if [ ! -f "test.cpp" ]; then
    echo "❌ 错误: 未找到 test.cpp 文件"
    echo "当前目录中的文件:"
    ls -la *.cpp 2>/dev/null || echo "未找到任何 .cpp 文件"
    exit 1
fi

echo "✅ 找到 test.cpp 文件"

# 3. 显示 test.cpp 文件信息
echo "📊 test.cpp 文件信息:"
ls -la test.cpp
echo "文件大小: $(wc -l < test.cpp) 行"

echo "------------------------------------------"

# 4. 创建输出目录（如果不存在）
OUTPUT_DIR="/app/output"
echo "创建输出目录: $OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

# 5. 复制 case 目录到输出目录
echo "📁 复制 case 目录到输出目录..."
for case_dir in case*; do
    if [ -d "$case_dir" ]; then
        echo "复制 $case_dir..."
        cp -r "$case_dir" "$OUTPUT_DIR/"
    fi
done

# 6. 编译 C++ 程序到输出目录
echo "🔨 开始编译 C++ 程序..."
echo "执行命令: g++ -o $OUTPUT_DIR/test test.cpp -std=c++11"

g++ -o "$OUTPUT_DIR/test" test.cpp -std=c++11

# 7. 检查编译是否成功
if [ $? -eq 0 ]; then
    echo "✅ 编译成功!"
    
    # 显示生成的可执行文件信息
    echo "📦 生成的可执行文件:"
    ls -la "$OUTPUT_DIR/test"
    echo "文件类型: $(file "$OUTPUT_DIR/test" 2>/dev/null || echo '无法检测文件类型')"
    
    # 设置执行权限
    chmod +x "$OUTPUT_DIR/test"
    echo "🔒 已设置执行权限"
    
    # 8. 复制其他必要文件到输出目录
    echo "📄 复制其他必要文件..."
    cp test.cpp "$OUTPUT_DIR/" 2>/dev/null && echo "✅ 复制 test.cpp"
    cp metadata.yaml "$OUTPUT_DIR/" 2>/dev/null && echo "✅ 复制 metadata.yaml"
    cp test.sh "$OUTPUT_DIR/" 2>/dev/null && echo "✅ 复制 test.sh"
    
    # 9. 显示输出目录内容
    echo "------------------------------------------"
    echo "📁 输出目录内容 ($OUTPUT_DIR):"
    ls -la "$OUTPUT_DIR"
    
    echo "------------------------------------------"
    echo "🎉 编译完成! 可执行文件: $OUTPUT_DIR/test"
    echo "=========================================="
    
else
    echo "❌ 编译失败!"
    echo "=========================================="
    exit 1
fi